# Build

1. `npm install`
1. `npm run dist`
1. The installer will be placed at `dist` folder.
