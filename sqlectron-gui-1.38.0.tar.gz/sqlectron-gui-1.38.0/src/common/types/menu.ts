import { App } from 'electron';

export type BuildWindow = (app: App) => void; // eslint-disable-line no-unused-vars
